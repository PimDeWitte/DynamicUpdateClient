#!/bin/bash
echo "This is a test version 0.0.0 to install, should return 0"
exit 0
#download 4.3.2.zip
#backup
