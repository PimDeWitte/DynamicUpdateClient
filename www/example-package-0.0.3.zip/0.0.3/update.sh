#!/bin/bash
echo "Attempting to update to 0.0.3 (this one should return exit code 0 successfully)"
exit 0
#download 4.3.2.zip
#backup
