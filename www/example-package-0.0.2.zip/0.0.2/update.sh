#!/bin/bash
echo "Updating OpenMRS to version 0.0.2 (this one is supposed to exit return code 2 which is a fail and ignore)"
echo "Our parameters are:\n"
echo $@
exit 1
#download 4.3.2.zip
#backup
